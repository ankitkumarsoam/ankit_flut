import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'trippin',
      home: Scaffold(
        body:Center(
            child: Text('Team trippin', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 40 , ),),

        )
      )
    )
  );
}



   